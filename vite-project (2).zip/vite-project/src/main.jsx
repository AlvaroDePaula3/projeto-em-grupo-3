import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Programacao from './components/Programacao'
import Filmes from './components/Filmes'
import Login from './components/Login'
import Carrinho from './components/Carrinho'
import Menu from './components/NavBar'

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
  <Menu/>
    <Routes>
      <Route path="/" element={<Home/>} />
      <Route path="/Filmes" element={<Filmes/>} />
      <Route path="/Programacao" element={<Programacao/>} />
      <Route path="/Login" element={<Login/>} />
      <Route path="/Carrinho" element={<Carrinho/>} />

    </Routes>
  </BrowserRouter>
)
