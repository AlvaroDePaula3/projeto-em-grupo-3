import React from 'react'
import './style.css'
import atual1 from '../Editado/atual1.jpg'
import atual2 from '../Editado/atual2.jpg'
import atual3 from '../Editado/atual3.jpg'
import atual4 from '../Editado/atual4.jpg'
import antigo1 from '../Editado/antigo1.jpg'
import antigo2 from '../Editado/antigo2.png'
import antigo3 from '../Editado/antigo3.jpg'
import antigo4 from '../Editado/antigo4.jpg'
import { useState } from 'react'
import { useEffect } from 'react'
import axios from 'axios';

function Filmes() {

  useEffect(() => {
    axios.get("http://localhost:3000/filmes").then((dados) => setMovies(dados.data)).catch((error) => console.log(error));
  }
  , [])

  const [movies, setMovies] = useState([]);

  return (
    <div>
        <h1 id='film'>Filmes</h1>
      {movies.map(function(movies, index){
        return (
          <div className='card'>
          <img src={atual1} />  
            <h1>{movies.nome}</h1>
            <hr />
            <p>{movies.genero}</p>
            <hr />
          <p> Adão Negro é o filme solo do anti-herói, baseado no personagem em quadrinhos Black Adam (Dwayne Johnson) da DC Comics, grande antagonista de Shazam!, tendo no longa, sua história de origem explorada, e revelando seu passado de escravo no país Kahndaq. Nascido no Egito Antigo, o anti-herói tem super força, velocidade, resistência, capacidade de voar e de disparar raios. Alter ego de Teth-Adam e filho do faraó Ramsés II, Adão Negro foi consumido por poderes mágicos e transformado em um feiticeiro. Grande inimigo de Shazam! nas HQs, apesar dele acreditar em seu pontecial e, inclusive, oferecê-lo como um guerreiro do bem, Adão Negro acaba usando suas habilidades especiais para o mal. O anti-herói em busca de redenção ou um herói que se tornou vilão, pode ser capaz de destruir tudo o que estiver pela frente - ou de encontrar seu caminho. </p>     
          <hr />
          <p>Direção: Jaume Collet-Serra </p>
          <hr />
          <p> Elenco: Dwayne Johnson, Aldis Hodge, Pierce Brosnan</p>
        </div>
        )
      })}
        
    </div>
  )
}

export default Filmes