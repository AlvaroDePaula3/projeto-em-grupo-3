import React from 'react'

function Carrinho() {
  return (
    <div>index</div>
  )
}

export default Carrinho