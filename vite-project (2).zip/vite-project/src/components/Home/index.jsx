import React from 'react'
import '../Home/style.css'
import atual1 from '../Editado/atual1.jpg'
import atual2 from '../Editado/atual2.jpg'
import atual3 from '../Editado/atual3.jpg'
import atual4 from '../Editado/atual4.jpg'
import antigo1 from '../Editado/antigo1.jpg'
import antigo2 from '../Editado/antigo2.png'
import antigo3 from '../Editado/antigo3.jpg'
import antigo4 from '../Editado/antigo4.jpg'
import preco1 from '../Editado/preco1.png'



function Home() {
  return (
    <div>
      <div className='Baner'>
      <img src={preco1} alt="Preço" />
      </div>
      <h1>Programação</h1>
      <h2>Em cartaz</h2>
      <div className='poster'>
        <img onClick={() => window.location.href="./Carrinho" }src={atual1} />
        <img onClick={() => window.location.href="./Carrinho" }src={atual2} />
        <img onClick={() => window.location.href="./Carrinho" }src={atual3} />
        <img onClick={() => window.location.href="./Carrinho" }src={atual4} />
      </div>
      <br />
      <hr />
      <h2>Em Breve</h2>
      <div className='poster'>
        <img onClick={() => window.location.href="./Carrinho" }src={antigo1} />
        <img onClick={() => window.location.href="./Carrinho" }src={antigo2} />
        <img onClick={() => window.location.href="./Carrinho" }src={antigo3} />
        <img onClick={() => window.location.href="./Carrinho" }src={antigo4} />
      </div>
      

    </div>
  )
}

export default Home